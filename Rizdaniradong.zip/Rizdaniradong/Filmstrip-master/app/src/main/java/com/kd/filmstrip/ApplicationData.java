package com.kd.filmstrip;

public class ApplicationData {
	public static final String CLIENT_ID = " ";
	public static final String CLIENT_SECRET = " ";

	
	
	
}
