package br.com.dina.oauth.instagram;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.Context;

/**
 * Manage access token and user name. Uses shared preferences to store access
 * token and user name.
 * 
 * @author Thiago Locatelli <thiago.locatelli@gmail.com>
 * @author Lorensius W. L T <lorenz@londatiga.net>
 * 
 */
public class InstagramSession {

	private SharedPreferences sharedPref;
	private Editor editor;

	private static final String SHARED = "Instagram_Preferences";
	private static final String API_USERNAME = "username";
	private static final String API_ID = "id";
	private static final String API_NAME = "name";
	private static final String API_ACCESS_TOKEN = "access_token";
	private static final String API_PROFILEPIC = "profile_pic";
	private static final String API_MEDIA_NUM = "media";
	private static final String API_FOLLOWS_NUM = "follows";
	private static final String API_FOLLOWED_BY = "followed_by";

	public InstagramSession(Context context) {
		sharedPref = context.getSharedPreferences(SHARED, Context.MODE_PRIVATE);
		editor = sharedPref.edit();
	}

	/**
	 * 
	 * @param accessToken
	 * @param expireToken
	 * @param expiresIn
	 * @param username
	 */
	public void storeAccessToken(String accessToken, String id, String username, String name, String profile_pic, int media, int follows, int followed_by) {
		editor.putString(API_ID, id);
		editor.putString(API_NAME, name);
		editor.putString(API_ACCESS_TOKEN, accessToken);
		editor.putString(API_USERNAME, username);
		editor.putString(API_PROFILEPIC, profile_pic);
		editor.putInt(API_MEDIA_NUM, media);
		editor.putInt(API_FOLLOWS_NUM, follows);
		editor.putInt(API_FOLLOWED_BY, followed_by);
		editor.commit();
	}

	public void storeAccessToken(String accessToken) {
		editor.putString(API_ACCESS_TOKEN, accessToken);
		editor.commit();
	}
	public void updateInfo(String username, String name, String profile_pic, int media, int follows, int followed_by) {
		editor.putString(API_NAME, name);
		editor.putString(API_USERNAME, username);
		editor.putString(API_PROFILEPIC, profile_pic);
		editor.putInt(API_MEDIA_NUM, media);
		editor.putInt(API_FOLLOWS_NUM, follows);
		editor.putInt(API_FOLLOWED_BY, followed_by);
		editor.commit();
	}
	/**
	 * Reset access token and user name
	 */
	public void resetAccessToken() {
		editor.putString(API_ID, null);
		editor.putString(API_NAME, null);
		editor.putString(API_ACCESS_TOKEN, null);
		editor.putString(API_USERNAME, null);
		editor.putString(API_PROFILEPIC, null);
		editor.putString(API_MEDIA_NUM, null);
		editor.putString(API_FOLLOWS_NUM, null);
		editor.putString(API_FOLLOWED_BY, null);
		editor.commit();
	}

	/**
	 * Get user name
	 * 
	 * @return User name
	 */
	public String getUsername() {
		return sharedPref.getString(API_USERNAME, null);
	}
	
	/**
	 * 
	 * @return
	 */
	public String getId() {
		return sharedPref.getString(API_ID, null);
	}
	
	/**
	 * 
	 * @return
	 */
	public String getName() {
		return sharedPref.getString(API_NAME, null);
	}
	
	/**
	 * 
	 * @return
	 */
	public String getProfilePic() {
		return sharedPref.getString(API_PROFILEPIC, null);
	}
	public int getMediaNumber() {
		return sharedPref.getInt(API_MEDIA_NUM, 0);
	}
	public int getFollows() {
		return sharedPref.getInt(API_FOLLOWS_NUM, 0);
	}
	public int getFollowedBy() {
		return sharedPref.getInt(API_FOLLOWED_BY, 0);
	}

	/**
	 * Get access token
	 * 
	 * @return Access token
	 */
	public String getAccessToken() {
		return sharedPref.getString(API_ACCESS_TOKEN, null);
	}

}